<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmbdf2fbm
#Region "Windows �t�H�[�� �f�U�C�i�ɂ���Đ������ꂽ�R�[�h "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'���̌Ăяo���́AWindows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
		InitializeComponent()
	End Sub
	'Form �́A�R���|�[�l���g�ꗗ�Ɍ㏈�������s���邽�߂� dispose ���I�[�o�[���C�h���܂��B
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents cmdBdfFile As System.Windows.Forms.Button
	Public WithEvents txtBdfFile As System.Windows.Forms.TextBox
	Public WithEvents cmdConvert As System.Windows.Forms.Button
	Public cdlgBdfFileOpen As System.Windows.Forms.OpenFileDialog
	'����: �ȉ��̃v���V�[�W���� Windows �t�H�[�� �f�U�C�i�ŕK�v�ł��B
	'Windows �t�H�[�� �f�U�C�i���g���ĕύX�ł��܂��B
	'�R�[�h �G�f�B�^���g�p���āA�ύX���Ȃ��ł��������B
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cmdBdfFile = New System.Windows.Forms.Button
        Me.txtBdfFile = New System.Windows.Forms.TextBox
        Me.cmdConvert = New System.Windows.Forms.Button
        Me.cdlgBdfFileOpen = New System.Windows.Forms.OpenFileDialog
        Me.SuspendLayout()
        '
        'cmdBdfFile
        '
        Me.cmdBdfFile.BackColor = System.Drawing.SystemColors.Control
        Me.cmdBdfFile.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdBdfFile.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdBdfFile.Location = New System.Drawing.Point(256, 8)
        Me.cmdBdfFile.Name = "cmdBdfFile"
        Me.cmdBdfFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdBdfFile.Size = New System.Drawing.Size(57, 19)
        Me.cmdBdfFile.TabIndex = 0
        Me.cmdBdfFile.Text = "BDF"
        Me.cmdBdfFile.UseVisualStyleBackColor = False
        '
        'txtBdfFile
        '
        Me.txtBdfFile.AcceptsReturn = True
        Me.txtBdfFile.BackColor = System.Drawing.SystemColors.Window
        Me.txtBdfFile.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBdfFile.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtBdfFile.Location = New System.Drawing.Point(16, 8)
        Me.txtBdfFile.MaxLength = 0
        Me.txtBdfFile.Name = "txtBdfFile"
        Me.txtBdfFile.ReadOnly = True
        Me.txtBdfFile.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtBdfFile.Size = New System.Drawing.Size(233, 18)
        Me.txtBdfFile.TabIndex = 2
        Me.txtBdfFile.TabStop = False
        '
        'cmdConvert
        '
        Me.cmdConvert.BackColor = System.Drawing.SystemColors.Control
        Me.cmdConvert.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdConvert.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdConvert.Location = New System.Drawing.Point(16, 40)
        Me.cmdConvert.Name = "cmdConvert"
        Me.cmdConvert.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdConvert.Size = New System.Drawing.Size(297, 49)
        Me.cmdConvert.TabIndex = 1
        Me.cmdConvert.Text = "Convert"
        Me.cmdConvert.UseVisualStyleBackColor = False
        '
        'cdlgBdfFileOpen
        '
        Me.cdlgBdfFileOpen.Filter = "Bdf files (*.bdf)|*.bdf|All Files (*.*)|*.*"
        '
        'frmbdf2fbm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(331, 97)
        Me.Controls.Add(Me.cmdBdfFile)
        Me.Controls.Add(Me.txtBdfFile)
        Me.Controls.Add(Me.cmdConvert)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("�l�r �S�V�b�N", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Location = New System.Drawing.Point(3, 29)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmbdf2fbm"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text = "bdf2fbm"
        Me.ResumeLayout(False)

    End Sub
#End Region 
End Class