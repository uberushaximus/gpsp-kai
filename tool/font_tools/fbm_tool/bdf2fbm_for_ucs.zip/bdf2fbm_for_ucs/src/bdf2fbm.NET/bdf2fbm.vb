Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmbdf2fbm
	Inherits System.Windows.Forms.Form
	
	
	Const cTAG_WxH As String = "FONTBOUNDINGBOX "
	Const cTAG_CharSet As String = "CHARSET_REGISTRY "
	Const cTAG_Default As String = "DEFAULT_CHAR "
	Const cTAG_Font As String = "ENCODING "
	
	
	Private Structure typFont
		Dim bytWidth As Byte
		Dim bytFont() As Byte
	End Structure
	
	
	Private Structure typFontMap
		<VBFixedArray(1)> Dim bytStart() As Byte
		<VBFixedArray(1)> Dim bytEnd() As Byte
		<VBFixedArray(1)> Dim bytDistance() As Byte
		
        Public Sub Initialize()
            ReDim bytStart(1)
            ReDim bytEnd(1)
            ReDim bytDistance(1)
        End Sub
	End Structure
	
	
	Private Structure typFontControl
		<VBFixedArray(1)> Dim bytFontCnt() As Byte
		<VBFixedArray(1)> Dim bytMapCnt() As Byte
		<VBFixedArray(1)> Dim bytDefault() As Byte
		Dim bytWidth As Byte
		Dim bytHeight As Byte
		Dim bytByteParChar As Byte
		
        Public Sub Initialize()
            ReDim bytFontCnt(1)
            ReDim bytMapCnt(1)
            ReDim bytDefault(1)
        End Sub
	End Structure
	
	
	Private Sub cmdBdfFile_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdBdfFile.Click
		Dim strWork As String
		Dim intCnt As Short
		
		
		On Error GoTo Cancel_Label
		
		cdlgBdfFileOpen.ShowDialog()
		txtBdfFile.Text = cdlgBdfFileOpen.FileName
		
		On Error Resume Next
		
Cancel_Label: 
		System.Windows.Forms.Application.DoEvents()
	End Sub
	
	
	Private Sub cmdConvert_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdConvert.Click
		Dim strFontFile As String
		Dim strBuf As String
		Dim strCharset As String
		Dim usrFont() As typFont
        Dim lngCode() As Integer
        Dim usrFontControl As typFontControl
		Dim usrFontMap() As typFontMap
		Dim lngFontCnt As Integer
		Dim lngMapCnt As Integer
		Dim intWidth As Short
		Dim intHeight As Short
		Dim lngDefaultTemp As Integer
		Dim lngDefault As Integer
		Dim lngCnt As Integer

        usrFontControl.Initialize()

		If txtBdfFile.Text = "" Then Exit Sub
		
		strBuf = txtBdfFile.Text
		
		For lngCnt = Len(strBuf) To 1 Step -1
			If Mid(strBuf, lngCnt, 1) = "." Then
				strBuf = VB.Left(strBuf, lngCnt - 1)
				Exit For
			ElseIf Mid(strBuf, lngCnt, 1) = "\" Then 
				Exit For
			End If
		Next 
		
		strFontFile = strBuf & ".fbm"
		
		Me.Cursor = System.Windows.Forms.Cursors.WaitCursor
		cmdConvert.Text = "Processing ..."
		
		lngFontCnt = 0
		lngMapCnt = 0
		intWidth = 0
		intHeight = 0
		lngDefaultTemp = 0
		lngDefault = 0
		
		FileOpen(1, txtBdfFile.Text, OpenMode.Input, OpenAccess.Read)
		
		Do While Not EOF(1)
			fgets(1, strBuf)
			
			If cTAG_WxH = VB.Left(strBuf, Len(cTAG_WxH)) Then
				strBuf = Mid(strBuf, Len(cTAG_WxH) + 1, Len(strBuf) - Len(cTAG_WxH) + 1)
				intWidth = CShort(VB.Left(strBuf, InStr(1, strBuf, " ") - 1))
				strBuf = VB.Right(strBuf, Len(strBuf) - InStr(1, strBuf, " "))
				intHeight = CShort(VB.Left(strBuf, InStr(1, strBuf, " ") - 1))
				Debug.Print("WIDTHxHEIGHT:" & intWidth & "x" & intHeight)
			ElseIf cTAG_CharSet = VB.Left(strBuf, Len(cTAG_CharSet)) Then 
				strBuf = Mid(strBuf, Len(cTAG_CharSet) + 1, Len(strBuf) - Len(cTAG_CharSet) + 1)
				strBuf = Mid(strBuf, InStr(1, strBuf, """") + 1)
				strCharset = VB.Left(strBuf, InStr(1, strBuf, """") - 1)
				
				If fncCharsetCheck(strCharset) < 0 Then
					MsgBox("CHARSET is not support! [" & strCharset & "]", MsgBoxStyle.Exclamation + MsgBoxStyle.OKOnly, "Error")
					FileClose(1)
					GoTo End_Label
				End If
				
				Debug.Print("CODESET:" & strCharset)
			ElseIf cTAG_Default = VB.Left(strBuf, Len(cTAG_Default)) Then 
				strBuf = Mid(strBuf, Len(cTAG_Default) + 1, Len(strBuf) - Len(cTAG_Default) + 1)
				lngDefaultTemp = fncCharCodeConv(strCharset, CInt(strBuf))
				Debug.Print("DEFAULT_CHAR:" & lngDefaultTemp)
			ElseIf cTAG_Font = VB.Left(strBuf, Len(cTAG_Font)) Then 
				If intWidth = 0 Or intHeight = 0 Then Exit Do
				
                ReDim Preserve usrFont(lngFontCnt)
                usrFont.Initialize()

                ReDim Preserve lngCode(lngFontCnt)
                lngCode.Initialize()

                strBuf = Mid(strBuf, Len(cTAG_Font) + 1, Len(strBuf) - Len(cTAG_Font) + 1)
				lngCode(lngFontCnt) = fncCharCodeConv(strCharset, CInt(strBuf))
				ReDim usrFont(lngFontCnt).bytFont(Int(intWidth / 8 + 0.99999) * intHeight - 1)
				
				subMkFont(1, usrFont(lngFontCnt), Int(intWidth / 8 + 0.99999))
				lngFontCnt = lngFontCnt + 1
			End If
		Loop 
		
		FileClose(1)
		
		If intWidth = 0 Or intHeight = 0 Or lngFontCnt = 0 Then
			MsgBox("File is not support !", MsgBoxStyle.Exclamation + MsgBoxStyle.OKOnly, "Error")
			GoTo End_Label
		End If
		
		lngMapCnt = 0
        ReDim usrFontMap(0)
        usrFontMap(0).Initialize()

		subShort2Byte(lngCode(0), usrFontMap(0).bytStart)
		subShort2Byte(lngCode(0), usrFontMap(0).bytEnd)
		subShort2Byte(lngCode(0) - 0, usrFontMap(0).bytDistance)
		If lngCode(0) = lngDefaultTemp Then lngDefault = 0
		
		For lngCnt = 1 To UBound(usrFont)
			If lngCode(lngCnt) <> lngCode(lngCnt - 1) + 1 Then
				lngMapCnt = lngMapCnt + 1
                ReDim Preserve usrFontMap(lngMapCnt)
                usrFontMap(lngMapCnt).Initialize()

				With usrFontMap(lngMapCnt)
					subShort2Byte(lngCode(lngCnt), .bytStart)
					subShort2Byte(lngCode(lngCnt) - lngCnt, .bytDistance)
				End With
			End If
			
			If lngCode(lngCnt) = lngDefaultTemp Then lngDefault = lngCnt
			subShort2Byte(lngCode(lngCnt), usrFontMap(lngMapCnt).bytEnd)
		Next 
		
		lngMapCnt = lngMapCnt + 1
		
		If lngDefault > UBound(usrFont) Then lngDefault = 0
		
		With usrFontControl
			subShort2Byte(lngFontCnt, .bytFontCnt)
			subShort2Byte(lngMapCnt, .bytMapCnt)
			subShort2Byte(lngDefault, .bytDefault)
			.bytWidth = CByte(intWidth)
			.bytHeight = CByte(intHeight)
			.bytByteParChar = CByte(Int(intWidth / 8 + 0.99999) * intHeight)
		End With
		
		For lngCnt = 1 To UBound(usrFontMap)
			If usrFontMap(lngCnt - 1).bytStart(1) > usrFontMap(lngCnt).bytStart(1) Or (usrFontMap(lngCnt - 1).bytStart(1) = usrFontMap(lngCnt).bytStart(1) And usrFontMap(lngCnt - 1).bytStart(0) > usrFontMap(lngCnt).bytStart(0)) Then
				Debug.Print("ERROR:" & lngCnt)
			End If
		Next 
		
		FileOpen(1, strFontFile, OpenMode.Binary, OpenAccess.Write)
		
        FilePut(1, usrFontControl)
        FilePut(1, usrFontMap)
		
		For lngCnt = 0 To UBound(usrFont)
            FilePut(1, usrFont(lngCnt).bytWidth)
            FilePut(1, usrFont(lngCnt).bytFont)
		Next 
		
		FileClose(1)
		
		
End_Label: 
        cmdConvert.Text = "Convert"
	End Sub
	
	
    Private Function fncCharsetCheck(ByRef strCharset As String) As Short
        If StrConv(VB.Left(strCharset, Len("ISO8859")), VbStrConv.Uppercase) = "ISO8859" Then
            fncCharsetCheck = 0
        ElseIf StrConv(VB.Left(strCharset, Len("JISX0201")), VbStrConv.Uppercase) = "JISX0201" Then
            fncCharsetCheck = 1
        ElseIf StrConv(VB.Left(strCharset, Len("JISX0208")), VbStrConv.Uppercase) = "JISX0208" Then
            fncCharsetCheck = 2
        ElseIf StrConv(VB.Left(strCharset, Len("ISO10646")), VbStrConv.Uppercase) = "ISO10646" Then
            fncCharsetCheck = 3
        Else
            fncCharsetCheck = -1
        End If
    End Function
	
	
	Private Function fncCharCodeConv(ByRef strCharset As String, ByRef lngCode As Integer) As Integer
		Select Case fncCharsetCheck(strCharset)
			Case 2 ' JISX0208
				fncCharCodeConv = fncJis2Sjis(lngCode)

            Case 3 ' JISX0208
                fncCharCodeConv = lngCode

			Case Else
				fncCharCodeConv = lngCode
		End Select
	End Function
	
	
	Private Function fncJis2Sjis(ByRef lngCode As Integer) As Integer
		Dim lngC1 As Integer
		Dim lngC2 As Integer
		
		
		lngC1 = Int(lngCode / 256)
		lngC2 = Int(lngCode Mod 256)
		
		If lngC1 = 0 Then
			fncJis2Sjis = lngCode
			Exit Function
		End If
		
		If (lngC1 Mod 2) = 0 Then
			lngC2 = lngC2 + &H7D
		Else
			lngC2 = lngC2 + &H1F
		End If
		
		If lngC2 > &H7E Then lngC2 = lngC2 + 1
		
		If lngC1 < &H5F Then
			lngC1 = Int((lngC1 + 1) / 2) + &H70
		Else
			lngC1 = Int((lngC1 + 1) / 2) + &HB0
		End If
		
		fncJis2Sjis = lngC1 * 256 + lngC2
	End Function
	
	
    Private Sub subShort2Byte(ByRef lngDat As Integer, ByRef bytDat() As Byte)
        bytDat(0) = CByte(lngDat Mod 256)
        bytDat(1) = CByte(Int(lngDat / 256))
    End Sub
	
	
	Private Sub subMkFont(ByRef fp As Short, ByRef usrFont As typFont, ByRef intWidth As Short)
		Dim strBuf As String
		Dim strWork As String
		Dim intLen As Short
		Dim intCnt As Short
		Dim intPixel As Short
		
		
		Do While Not EOF(1)
			fgets(1, strBuf)
			
			If "DWIDTH " = VB.Left(strBuf, Len("DWIDTH ")) Then
				strWork = Mid(strBuf, Len("DWIDTH ") + 1, InStr(Len("DWIDTH "), strBuf, " ") - Len("DWIDTH ") + 2)
				usrFont.bytWidth = CByte(strWork)
			ElseIf "BITMAP" = VB.Left(strBuf, Len("BITMAP")) Then 
				Do While Not EOF(1)
					fgets(1, strBuf)
					
					If "ENDCHAR" = VB.Left(strBuf, Len("ENDCHAR")) Then Exit Sub
					
					intLen = Int(Len(strBuf) / 2)
					
					With usrFont
						For intCnt = 0 To intWidth - 1
							.bytFont(intPixel + intCnt) = fncHexStr2Byte(Mid(strBuf, intCnt * 2 + 1, 2))
						Next 
						
						intPixel = intPixel + intWidth
					End With
				Loop 
			End If
		Loop 
	End Sub
	
	
	Private Function fncHexStr2Byte(ByRef strHexStr As String) As Byte
		fncHexStr2Byte = 0
		fncHexStr2Byte = fncHexChar2Int(VB.Left(strHexStr, 1)) * 16 + fncHexChar2Int(VB.Right(strHexStr, 1))
	End Function
	
	
	Private Function fncHexChar2Int(ByRef strHexChar As String) As Short
		fncHexChar2Int = 0
		
		If strHexChar >= "0" And strHexChar <= "9" Then
			fncHexChar2Int = Int(CDbl(strHexChar))
		ElseIf StrConv(strHexChar, VbStrConv.UpperCase) >= "A" And StrConv(strHexChar, VbStrConv.UpperCase) <= "F" Then 
			fncHexChar2Int = Asc(StrConv(strHexChar, VbStrConv.UpperCase)) - Asc("A") + 10
		End If
	End Function
	
	
	Private Function fgets(ByRef fp As Short, ByRef strBuf As String) As Short
		Static bln0x0D As Boolean
		Static bln0x0A As Boolean
		Dim strChar As String
		
		
		fgets = 0
		strBuf = ""
		
		Do While Not EOF(1)
			strChar = InputString(1, 1)
			
			If Asc(strChar) = &HD Then
				If bln0x0A Then
					bln0x0A = False
				Else
					bln0x0D = True
					Exit Do
				End If
			ElseIf Asc(strChar) = &HA Then 
				If bln0x0D Then
					bln0x0D = False
				Else
					bln0x0A = True
					Exit Do
				End If
			ElseIf Asc(strChar) = 0 Then 
				bln0x0A = False
				bln0x0D = False
				Exit Do
			Else
				bln0x0A = False
				bln0x0D = False
				strBuf = strBuf & strChar
				fgets = fgets + 1
			End If
		Loop 
	End Function
End Class